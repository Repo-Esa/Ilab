<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    use HasFactory;

    protected $fillable = ['nama', 'photo'];

    // 🔹 Accessor untuk foto
    public function getPhotoUrlAttribute()
    {
        return asset('images/' . ($this->photo ?? 'man.png'));
    }

    public function schedules()
    {
        return $this->hasMany(Jadwal::class);
    }
}
