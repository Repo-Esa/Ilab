<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Jadwal extends Model
{
    protected $fillable = [
        'guru_id',
        'ruangan_id',
        'subject_id',
        'day',
        'start_time',
        'end_time'
    ];

    public function guru()
    {
        return $this->belongsTo(Guru::class);
    }

    public function ruangan()
    {
        return $this->belongsTo(Ruangan::class);
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class);
    }
}
