@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Tambah Jadwal</h2>

    <a href="{{ route('jadwal.index') }}" class="btn btn-secondary mb-3">Kembali</a>

    <form action="{{ route('jadwal.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label for="guru_id" class="form-label">Guru</label>
            <select name="guru_id" id="guru_id" class="form-control" required>
                <option value="">-- Pilih Guru --</option>
                @foreach ($gurus as $guru)
                    <option value="{{ $guru->id }}">{{ $guru->nama }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="ruangan_id" class="form-label">Ruangan</label>
            <select name="ruangan_id" id="ruangan_id" class="form-control" required>
                <option value="">-- Pilih Ruangan --</option>
                @foreach ($ruangans as $ruangan)
                    <option value="{{ $ruangan->id }}">{{ $ruangan->nama }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="subject_id" class="form-label">Mata Pelajaran</label>
            <select name="subject_id" id="subject_id" class="form-control" required>
                <option value="">-- Pilih Mapel --</option>
                @foreach ($subjects as $subject)
                    <option value="{{ $subject->id }}">{{ $subject->nama }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="day" class="form-label">Hari</label>
            <select name="day" id="day" class="form-control" required>
                <option value="">-- Pilih Hari --</option>
                <option>Senin</option>
                <option>Selasa</option>
                <option>Rabu</option>
                <option>Kamis</option>
                <option>Jumat</option>
                <option>Sabtu</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="start_time" class="form-label">Jam Mulai</label>
            <input type="time" name="start_time" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="end_time" class="form-label">Jam Selesai</label>
            <input type="time" name="end_time" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Simpan Jadwal</button>
    </form>
</div>
@endsection
