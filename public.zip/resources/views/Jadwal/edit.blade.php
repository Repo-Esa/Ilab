@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Edit Jadwal</h2>

        <a href="{{ route('jadwal.index') }}" class="btn btn-secondary mb-3">Kembali</a>

        <form action="{{ route('jadwal.update', $jadwal->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label>Guru</label>
                <select name="guru_id" class="form-control" required>
                    @foreach ($gurus as $guru)
                        <option value="{{ $guru->id }}" {{ $jadwal->guru_id == $guru->id ? 'selected' : '' }}>
                            {{ $guru->nama }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label>Ruangan</label>
                <select name="ruangan_id" class="form-control" required>
                    @foreach ($ruangans as $ruangan)
                        <option value="{{ $ruangan->id }}" {{ $jadwal->ruangan_id == $ruangan->id ? 'selected' : '' }}>
                            {{ $ruangan->nama }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label>Mata Pelajaran</label>
                <select name="subject_id" class="form-control" required>
                    @foreach ($subjects as $subject)
                        <option value="{{ $subject->id }}" {{ $jadwal->subject_id == $subject->id ? 'selected' : '' }}>
                            {{ $subject->nama }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label>Hari</label>
                <select name="day" class="form-control" required>
                    @foreach (['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'] as $hari)
                        <option {{ $jadwal->day == $hari ? 'selected' : '' }}>{{ $hari }}</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label>Jam Mulai</label>
                <input type="time" name="start_time" class="form-control" value="{{ $jadwal->start_time }}" required>
            </div>

            <div class="mb-3">
                <label>Jam Selesai</label>
                <input type="time" name="end_time" class="form-control" value="{{ $jadwal->end_time }}" required>
            </div>

            <button type="submit" class="btn btn-success">Update Jadwal</button>
        </form>
    </div>
@endsection
