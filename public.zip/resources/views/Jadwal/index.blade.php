@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Daftar Jadwal Pelajaran</h2>
            <a href="{{ route('jadwal.create') }}" class="btn btn-primary">+ Tambah Jadwal</a>
        </div>

        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        @if ($jadwals->isEmpty())
            <div class="alert alert-info">Belum ada jadwal tersedia.</div>
        @else
            <div class="row">
                @foreach ($jadwals as $jadwal)
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm border-0">
                            <div class="card-body">
                                <h5 class="card-title text-primary">{{ $jadwal->subject->nama }}</h5>
                                <p class="mb-1"><strong>Guru:</strong> {{ $jadwal->guru->nama }}</p>
                                <p class="mb-1"><strong>Ruangan:</strong> {{ $jadwal->ruangan->nama }}</p>
                                <p class="mb-1">
                                    <strong>Hari:</strong>
                                    <span class="badge bg-info text-dark">{{ ucfirst($jadwal->day) }}</span>
                                </p>
                                <p class="mb-3">
                                    <strong>Waktu:</strong>
                                    <span class="badge bg-secondary">{{ $jadwal->start_time }} -
                                        {{ $jadwal->end_time }}</span>
                                </p>

                                <div class="d-flex justify-content-between">
                                    <a href="{{ route('jadwal.edit', $jadwal->id) }}"
                                        class="btn btn-warning btn-sm">Edit</a>

                                    <form action="{{ route('jadwal.destroy', $jadwal->id) }}" method="POST"
                                        onsubmit="return confirm('Yakin mau hapus jadwal ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-danger btn-sm">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
@endsection
