@extends('layouts.app')

@section('content')
    <h1 class="text-2xl font-bold mb-4">Monitoring Ruangan iLab</h1>

    <div class="grid grid-cols-4 gap-4 mb-6">
        <div class="bg-blue-600 text-white p-4 rounded-lg shadow">Total Ruangan</div>
        <div class="bg-yellow-400 text-white p-4 rounded-lg shadow">Berlangsung Sekarang</div>
        <div class="bg-green-600 text-white p-4 rounded-lg shadow">Selesai / Kosong</div>
        <div class="bg-cyan-400 text-white p-4 rounded-lg shadow">Belum Dimulai</div>
    </div>

    <h2 class="text-lg font-semibold mb-2">📅 Timeline Jadwal Hari Ini</h2>
    <table class="w-full bg-white shadow rounded-lg overflow-hidden">
        <thead class="bg-gray-200">
            <tr>
                <th class="p-2 text-left">Waktu</th>
                <th class="p-2 text-left">Ruangan</th>
                <th class="p-2 text-left">Guru</th>
                <th class="p-2 text-left">Mapel</th>
                <th class="p-2 text-left">Status</th>
            </tr>
        </thead>
        <tbody>
            <tr class="border-t">
                <td class="p-2">08:00 - 09:00</td>
                <td class="p-2">Lab 1</td>
                <td class="p-2">Pak Joko</td>
                <td class="p-2">Informatika</td>
                <td class="p-2 text-green-600">Selesai</td>
            </tr>
        </tbody>
    </table>
@endsection
