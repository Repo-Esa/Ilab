<footer class="text-center py-4 text-sm text-gray-500 dark:text-gray-400">
    © {{ date('Y') }} iLab Monitoring. All rights reserved.
</footer>