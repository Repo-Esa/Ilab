<nav class="bg-white shadow-md p-4 flex justify-between items-center">
    <div>
        <h1 class="text-2xl font-bold text-gray-800">iLab Monitoring</h1>
    </div>
    <div class="flex items-center space-x-4">
        <span id="clock" class="text-gray-600 font-semibold"></span>
        <div class="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
            {{ strtoupper(substr(Auth::user()->name ?? 'U', 0, 1)) }}
        </div>
    </div>
</nav>

<script>
    function updateClock() {
        const clock = document.getElementById('clock');
        const now = new Date();
        clock.textContent = now.toLocaleTimeString('id-ID');
    }
    setInterval(updateClock, 1000);
    updateClock();
</script>
