<aside class="w-64 bg-blue-600 text-white flex flex-col">
    <div class="text-center py-6 text-2xl font-bold border-b border-blue-500">
        <i class="fa-solid fa-flask"></i> iLab
    </div>
    <nav class="flex-1 px-4 py-4 space-y-2">
        <a href="{{ route('dashboard') }}" class="flex items-center p-2 rounded-lg hover:bg-blue-500">
            <i class="fa-solid fa-house mr-3"></i> Dashboard
        </a>
        <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-500">
            <i class="fa-solid fa-calendar mr-3"></i> Jadwal Mapel
        </a>
        <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-500">
            <i class="fa-solid fa-door-open mr-3"></i> Pemakaian Ruangan
        </a>
        <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-500">
            <i class="fa-solid fa-users mr-3"></i> Data Guru
        </a>
        <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-500">
            <i class="fa-solid fa-chart-column mr-3"></i> Laporan
        </a>
    </nav>
    <div class="p-4 border-t border-blue-500 text-sm">
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="w-full bg-blue-500 py-2 rounded hover:bg-blue-400">
                Logout
            </button>
        </form>
    </div>
</aside>
