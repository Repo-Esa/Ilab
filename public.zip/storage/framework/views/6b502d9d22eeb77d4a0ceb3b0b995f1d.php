<nav class="navbar navbar-light bg-white shadow-sm px-4">
    <span class="navbar-text ms-auto">Halo, Admin!</span>
</nav><?php /**PATH E:\laragon\www\Ilab\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>