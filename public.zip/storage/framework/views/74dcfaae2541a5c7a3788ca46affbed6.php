

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">📊 Monitoring Ruangan iLab</h3>
            <small class="text-muted">Pantau pemakaian ruangan secara real-time</small>
        </div>
        <div class="fs-5 fw-bold text-secondary" id="clock"></div>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card shadow-sm border-0 bg-primary text-white">
                <div class="card-body">
                    <h6>Total Ruangan</h6>
                    
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-0 bg-warning text-dark">
                <div class="card-body">
                    <h6>Berlangsung Sekarang</h6>
                    
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-0 bg-success text-white">
                <div class="card-body">
                    <h6>Selesai / Kosong</h6>
                    
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-0 bg-info text-white">
                <div class="card-body">
                    <h6>Belum Dimulai</h6>
                    
                </div>
            </div>
        </div>
    </div>

    
    <h5 class="fw-bold mb-3">🧭 Status Ruangan Hari Ini</h5>
    <div class="row">
        
    </div>

    
    <h5 class="fw-bold mt-5 mb-3">🕓 Timeline Jadwal Hari Ini</h5>
    <div class="table-responsive">
        <table class="table align-middle">
            <thead class="table-light">
                <tr>
                    <th>Waktu</th>
                    <th>Ruangan</th>
                    <th>Guru</th>
                    <th>Mapel</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
    </div>

</div>


<script>
    function updateClock() {
        const now = new Date();
        const h = String(now.getHours()).padStart(2, '0');
        const m = String(now.getMinutes()).padStart(2, '0');
        const s = String(now.getSeconds()).padStart(2, '0');
        document.getElementById('clock').textContent = `${h}:${m}:${s}`;
    }
    setInterval(updateClock, 1000);
    updateClock();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\Ilab\resources\views/layouts/Dashboard.blade.php ENDPATH**/ ?>