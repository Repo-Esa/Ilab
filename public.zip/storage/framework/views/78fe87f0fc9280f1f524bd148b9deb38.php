<footer class="text-center py-4 text-sm text-gray-500 dark:text-gray-400">
    © <?php echo e(date('Y')); ?> iLab Monitoring. All rights reserved.
</footer><?php /**PATH E:\laragon\www\Ilab\resources\views/footer.blade.php ENDPATH**/ ?>