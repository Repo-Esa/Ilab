

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Daftar Jadwal Pelajaran</h2>
            <a href="<?php echo e(route('jadwal.create')); ?>" class="btn btn-primary">+ Tambah Jadwal</a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($jadwals->isEmpty()): ?>
            <div class="alert alert-info">Belum ada jadwal tersedia.</div>
        <?php else: ?>
            <div class="row">
                <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm border-0">
                            <div class="card-body">
                                <h5 class="card-title text-primary"><?php echo e($jadwal->subject->nama); ?></h5>
                                <p class="mb-1"><strong>Guru:</strong> <?php echo e($jadwal->guru->nama); ?></p>
                                <p class="mb-1"><strong>Ruangan:</strong> <?php echo e($jadwal->ruangan->nama); ?></p>
                                <p class="mb-1">
                                    <strong>Hari:</strong>
                                    <span class="badge bg-info text-dark"><?php echo e(ucfirst($jadwal->day)); ?></span>
                                </p>
                                <p class="mb-3">
                                    <strong>Waktu:</strong>
                                    <span class="badge bg-secondary"><?php echo e($jadwal->start_time); ?> -
                                        <?php echo e($jadwal->end_time); ?></span>
                                </p>

                                <div class="d-flex justify-content-between">
                                    <a href="<?php echo e(route('jadwal.edit', $jadwal->id)); ?>"
                                        class="btn btn-warning btn-sm">Edit</a>

                                    <form action="<?php echo e(route('jadwal.destroy', $jadwal->id)); ?>" method="POST"
                                        onsubmit="return confirm('Yakin mau hapus jadwal ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\Ilab\resources\views/jadwal/index.blade.php ENDPATH**/ ?>