

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit Jadwal</h2>

        <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-secondary mb-3">Kembali</a>

        <form action="<?php echo e(route('jadwal.update', $jadwal->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label>Guru</label>
                <select name="guru_id" class="form-control" required>
                    <?php $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($guru->id); ?>" <?php echo e($jadwal->guru_id == $guru->id ? 'selected' : ''); ?>>
                            <?php echo e($guru->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Ruangan</label>
                <select name="ruangan_id" class="form-control" required>
                    <?php $__currentLoopData = $ruangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ruangan->id); ?>" <?php echo e($jadwal->ruangan_id == $ruangan->id ? 'selected' : ''); ?>>
                            <?php echo e($ruangan->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Mata Pelajaran</label>
                <select name="subject_id" class="form-control" required>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>" <?php echo e($jadwal->subject_id == $subject->id ? 'selected' : ''); ?>>
                            <?php echo e($subject->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Hari</label>
                <select name="day" class="form-control" required>
                    <?php $__currentLoopData = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($jadwal->day == $hari ? 'selected' : ''); ?>><?php echo e($hari); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Jam Mulai</label>
                <input type="time" name="start_time" class="form-control" value="<?php echo e($jadwal->start_time); ?>" required>
            </div>

            <div class="mb-3">
                <label>Jam Selesai</label>
                <input type="time" name="end_time" class="form-control" value="<?php echo e($jadwal->end_time); ?>" required>
            </div>

            <button type="submit" class="btn btn-success">Update Jadwal</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\Ilab\resources\views/jadwal/edit.blade.php ENDPATH**/ ?>