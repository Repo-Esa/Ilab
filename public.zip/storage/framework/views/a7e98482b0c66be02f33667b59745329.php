<div class="d-flex flex-column p-3 sidebar-modern">
    <a href="/" class="d-flex align-items-center mb-4 text-decoration-none">
        <i class="bi bi-grid fs-4 text-white me-2"></i>
        <span class="fs-5 fw-semibold text-white">iLab</span>
    </a>

    <ul class="nav nav-pills flex-column">
        <li class="nav-item">
            <a href="<?php echo e(route('Dashboard')); ?>"
                class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active bg-white text-dark fw-bold' : 'text-white'); ?>">
                <i class="bi bi-house me-2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(route('jadwalmapel')); ?>"
                class="nav-link <?php echo e(request()->routeIs('jadwalmapel') ? 'active bg-white text-dark fw-bold' : 'text-white'); ?>">
                <i class="bi bi-calendar3 me-2"></i> Jadwal Mapel
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white opacity-75 hover-bright">
                <i class="bi bi-door-open me-2"></i> Pemakaian Ruangan
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="#" class="nav-link text-white opacity-75 hover-bright">
                <i class="bi bi-person-lines-fill me-2"></i> Data Guru
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link text-white opacity-75 hover-bright">
                <i class="bi bi-bar-chart me-2"></i> Laporan
            </a>
        </li>
    </ul>
</div>
<?php /**PATH E:\laragon\www\Ilab\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>