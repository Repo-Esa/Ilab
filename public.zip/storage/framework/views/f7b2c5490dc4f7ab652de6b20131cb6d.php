

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="position-relative mb-4">
        <h3 class="fw-bold">📚 Jadwal Mata Pelajaran</h3>
        <button class="btn btn-primary position-absolute top-0 end-0" data-bs-toggle="modal" data-bs-target="#modalAdd">+ Tambah Jadwal</button>
        
    </div>

    
    <div class="btn-group mb-4" role="group">
        <?php $__currentLoopData = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('jadwal.index', ['day' => $d])); ?>"
                class="btn btn-sm <?php echo e((isset($day) && $day == $d) ? 'btn-primary' : 'btn-outline-primary'); ?>">
                <?php echo e($d); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="mb-2"><?php echo e($item->subject->nama); ?></h5>
                        <p class="mb-1"><b>Guru:</b> <?php echo e($item->guru->nama); ?></p>
                        <p class="mb-1"><b>Ruangan:</b> <?php echo e($item->ruangan->nama); ?></p>
                        <p class="mb-1"><b>Hari:</b> <?php echo e($item->hari); ?></p>
                        <p class="mb-2"><b>Waktu:</b> <?php echo e($item->jam_mulai); ?> - <?php echo e($item->jam_selesai); ?></p>
                        <div class="d-flex justify-content-end gap-2">
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?php echo e($item->id); ?>">Edit</button>
                            <form action="<?php echo e(route('jadwal.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-muted">Belum ada jadwal.</p>
        <?php endif; ?>
    </div>
</div>


<?php echo $__env->make('jadwal.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('jadwal.edit', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\Ilab\resources\views/jadwalmapel.blade.php ENDPATH**/ ?>